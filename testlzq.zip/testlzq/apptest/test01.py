from appium import webdriver
from selenium.common.exceptions import NoSuchElementException
