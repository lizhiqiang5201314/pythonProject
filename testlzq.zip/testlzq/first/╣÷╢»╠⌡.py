from selenium import  webdriver
from time import  sleep
driver = webdriver.Chrome()
driver.set_window_size(500,500)
driver.get("https://www.baidu.com/s?wd=%E5%A5%A5%E8%BF%90%E4%BC%9A&rsv_dl=pc_index_tips")
# driver.switch_to_frame('search')
# driver.find_element_by_css_selector('#query').send_keys("奥运会")
# driver.find_element_by_css_selector('#stb').click()
js= "window.scrollTo(500,1000);"
driver.execute_script(js)
